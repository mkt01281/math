import React from 'react';

 const Feilds = (props) => {

 return ( <p>{props.children}</p> )
};

export default Feilds;