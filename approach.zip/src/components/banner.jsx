import React from 'react';
import Logo from  '../assets/logo.png';

 const Banner = () => {
 return ( <div class="banner"><img src={Logo} alt="" class="banner-logo"/></div> )
};

export default Banner;